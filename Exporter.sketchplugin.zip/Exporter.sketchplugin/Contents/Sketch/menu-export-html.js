@import "export-cmd.js"


var onRun = function(context) {  
  return exportCmd(context)  
};

