@import("lib/nsui.js")
@import("lib/utils.js")
@import("constants.js")


var buildAlertWindow = function(annotations) {
  const alertWindow = COSAlertWindow.new();
  alertWindow.addButtonWithTitle("OK");
  alertWindow.addButtonWithTitle("Cancel");
  alertWindow.setMessageText("Edit Layer Annotations");

  const accessoryView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 300, 180));
  
  const annotationsLabel = NSUI.buildLabel("Annotatons:",0,NSMakeRect(0, 165, 300, 20))
  accessoryView.addSubview(annotationsLabel);

  const annotationsTextArea = NSUI.buildTextField(annotations,NSMakeRect(0, 20, 300, 145));
  accessoryView.addSubview(annotationsTextArea);

  alertWindow.addAccessoryView(accessoryView);

  return [alertWindow, annotationsTextArea];
};

var onRun = function(context) {
  const sketch = require('sketch')
  const Settings = require('sketch/settings')
  const UI = require('sketch/ui')
  const document = sketch.fromNative(context.document)
  const selection = document.selectedLayers

  // Check selection
  if(selection.length!=1){
    UI.alert("alert","Select a one layer.")
    return
  }
  var layer = selection.layers[0]

  // Get current settings for this layer (and reset to default if undefined)
  //--------------------------------------------------------------------
  var annotations = Settings.layerSettingForKey(layer,SettingKeys.LAYER_ANNOTATIONS)  
  if(annotations == undefined || annotations == null){
    annotations = ""
  }
  
  // Ask user for annotations
  const retVals = buildAlertWindow(annotations), alertWindow = retVals[0], annotationsTextArea = retVals[1]
  const response = alertWindow.runModal()
  if (response != 1000) return

  //Save new external annotations
  //--------------------------------------------------------------------
  Settings.setLayerSettingForKey(layer,SettingKeys.LAYER_ANNOTATIONS,annotationsTextArea.stringValue()+"")
  
}
