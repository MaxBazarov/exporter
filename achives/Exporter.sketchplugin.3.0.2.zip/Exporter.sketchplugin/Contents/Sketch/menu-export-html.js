@import "classes/exporter-run.js"

var onRun = function(context) {  
  return runExporter(context)  
};


